<?php
$CI = get_instance();
$CI->load->database();
$CI->load->dbforge();


$updated_date = array(
    'updated_date' => array(
        'type' => 'varchar',
        'default' => null,
        'null' => TRUE,
        'collation' => 'utf8_unicode_ci',
        'constraint' => '100'
    )
);
$CI->dbforge->add_column('user', $updated_date);

$purchase_code = array(
    'purchase_code' => array(
        'type' => 'varchar',
        'default' => null,
        'null' => TRUE,
        'collation' => 'utf8_unicode_ci',
        'constraint' => '100'
    )
);
$CI->dbforge->add_column('addons', $purchase_code);


$recaptcha_row['type'] = 'recaptcha_status';
$recaptcha_row['description'] = '0';
$CI->db->insert('settings', $recaptcha_row);

//update data in settings table
$settings_datas['description'] = '2.9';
$CI->db->where('type', 'version');
$CI->db->update('settings', $settings_datas);
?>
